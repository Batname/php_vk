<?php
$html = '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
    <title>Repost</title>
    <meta charset="UTF-8">
</head>
<body>
<h2>Последние темы блога</h2>
<!-- на 09.08.2009 -->
<table border="0">
<tbody>
<tr>
<td><a href="http://parsing-and-i.blogspot.com/2009/08/blog-post_06.html" title="Базы">http://parsing-and-i.blogspot.com/2009/08/blog-post_06.html</a></td>
<td>Базы</td>
</tr>

<tr>
<td><a href="http://parsing-and-i.blogspot.com/2009/08/mysql-delphi-express.html" title="MySQL и Delphi. Express-метод">http://parsing-and-i.blogspot.com/2009/08/mysql-delphi-express.html</a></td>
<td>MySQL и Delphi. Express-метод</td>
</tr>

<tr>
<td><a href="http://parsing-and-i.blogspot.com/2009/08/blog-post.html" title="Пост о том, что лучше сто раз проверить">http://parsing-and-i.blogspot.com/2009/08/blog-post.html</a></td>
<td>Пост о том, что лучше сто раз проверить</td>
</tr>

</tbody>
</table>

</body>
</html>
';
/** создаем новый dom-объект **/
$dom = new domDocument;

?> - See more at: http://parsing-and-i.blogspot.com/2009/08/html-php.html#sthash.wOQcP9Uy.dpuf